package com.ondocha.ondochaApp

data class RecordInfoListItem(
    var Atem : Double ? = null,
    var Code : String ? = null,
    var Confirmed : Boolean ? = null,
    var Disinfection : Boolean ? = null,
    var Ftem : Double ? = null,
    var Memo : String ? = null,
    var Name : String ? = null,
    var date : String ? = null,
    var time : String ? = null
)
